from rest_framework import serializers
from .models import faq

class faqSer(serializers.ModelSerializer):
    class Meta:
        model = faq
        fields = ['question', 'answer']