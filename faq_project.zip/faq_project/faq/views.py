from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import faq
from .serializer import faqSer
# Create your views here.
import openai


openai.api_key = ""

@api_view(['GET'])
def get_answer(request):
    question = request.query_params.get('question')

    if not question:
        return Response({"error": "WRONG INPUT"})
    
