from django.urls import path
from . import views

urlpatterns = [
    path("faqs/", views.get_answer, name= 'get_asswer'),
]